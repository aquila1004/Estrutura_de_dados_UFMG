#ifndef FIBONACCI__H
#define FIBONACCI__H
#define OP_FIBONACCI__H 2
 
unsigned long long  fibonacciRecursivo(int n);
unsigned long long fibonacciterativo(int n);

#endif
