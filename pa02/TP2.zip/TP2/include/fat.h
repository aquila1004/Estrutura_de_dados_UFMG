#ifndef FATORIAL__H
#define FATORIAL__H
#define OP_FATORIAL 1 

unsigned long long fatorialRecursivo(int n);
unsigned long long fatorialIterativo(int n);

#endif
